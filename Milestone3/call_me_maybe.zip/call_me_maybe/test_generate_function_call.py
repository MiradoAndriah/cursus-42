"""Test: génération complète d'un appel de fonction, bout en bout."""
import json

from llm_sdk import Small_LLM_Model
from src.generator import generate_function_call
from src.models import FunctionDefinition

print("Chargement du modèle...")
model = Small_LLM_Model()
print("Modèle chargé.\n")

vocab_path = model.get_path_to_vocab_file()
with open(vocab_path, encoding="utf-8") as f:
    vocab = json.load(f)
id_to_token = {v: k for k, v in vocab.items()}

tok_path = model.get_path_to_tokenizer_file()
with open(tok_path, encoding="utf-8") as f:
    tok_data = json.load(f)
for tok in tok_data.get("added_tokens", []):
    id_to_token[tok["id"]] = tok["content"]

with open("data/input/functions_definition.json", encoding="utf-8") as f:
    raw_functions = json.load(f)
all_functions = [FunctionDefinition.model_validate(f) for f in raw_functions]

prompt = f'Available functions: {json.dumps(raw_functions)}\n\nQuestion: Greet Safidyan.\nAnswer with a JSON object: '
ids_tensor = model.encode(prompt)
ids_list = ids_tensor[0].tolist()

result = generate_function_call(model, ids_list, all_functions, id_to_token)
print("\nJSON généré:", result)

# Vérifions que c'est du JSON valide
parsed = json.loads(result)
print("Parsing réussi:", parsed)
