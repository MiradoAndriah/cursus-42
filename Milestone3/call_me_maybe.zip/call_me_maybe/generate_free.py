"""Génération libre (SANS contrainte) - montre le problème à résoudre.
Lancer avec: uv run python generate_free.py"""
import json

from llm_sdk import Small_LLM_Model

print("Chargement du modèle...")
model = Small_LLM_Model()
print("Modèle chargé.\n")

# Construit le mapping complet id -> texte (vocab.json + tokens spéciaux)
vocab_path = model.get_path_to_vocab_file()
with open(vocab_path, encoding="utf-8") as f:
    vocab = json.load(f)
id_to_token = {v: k for k, v in vocab.items()}

# tok_path = model.get_path_to_tokenizer_file()
# with open(tok_path, encoding="utf-8") as f:
#     tok_data = json.load(f)
# for tok in tok_data.get("added_tokens", []):
#     id_to_token[tok["id"]] = tok["content"]

# print("Taille totale du mapping id->token:", len(id_to_token))
# print()

# Charge les définitions de fonctions (pour donner du contexte au prompt)
with open("data/input/functions_definition.json", encoding="utf-8") as f:
    functions = json.load(f)

# Construit un prompt simple qui inclut les fonctions dispo
prompt = f"""Available functions: {json.dumps(functions)}

Question: 1+1?
Answer with a JSON object containing "name" and "parameters":
"""

print("=== PROMPT ===")
print(prompt)
print("=== FIN PROMPT ===\n")

ids_tensor = model.encode(prompt)
ids_list = ids_tensor[0].tolist()

# Génère 40 tokens, SANS AUCUNE CONTRAINTE (juste argmax à chaque étape)
NB_TOKENS_A_GENERER = 40
generated_ids = []

for step in range(NB_TOKENS_A_GENERER):
    logits = model.get_logits_from_input_ids(ids_list)
    next_id = max(range(len(logits)), key=lambda i: logits[i])
    generated_ids.append(next_id)
    ids_list.append(next_id)

    token_text = id_to_token.get(next_id, f"<UNK id={next_id}>")
    print(f"étape {step:2d} | id={next_id:6d} | token={token_text!r}")

print()
print("=== TEXTE GÉNÉRÉ (brut) ===")
print(model.decode(generated_ids))
