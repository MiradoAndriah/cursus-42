"""Test: génération d'une valeur numérique, bout en bout."""
import json

from llm_sdk import Small_LLM_Model
from src.constrainer_number import generate_number_value
from src.constrainer_string import generate_string_value

print("Chargement du modèle...")
model = Small_LLM_Model()
print("Modèle chargé.\n")

vocab_path = model.get_path_to_vocab_file()
with open(vocab_path, encoding="utf-8") as f:
    vocab = json.load(f)
id_to_token = {v: k for k, v in vocab.items()}

tok_path = model.get_path_to_tokenizer_file()
with open(tok_path, encoding="utf-8") as f:
    tok_data = json.load(f)
for tok in tok_data.get("added_tokens", []):
    id_to_token[tok["id"]] = tok["content"]

prompt = 'Question: "greet john" Answer with a JSON: {"name": "fn_greet", "parameters": {"name": "'
ids_tensor = model.encode(prompt)
ids_list = ids_tensor[0].tolist()

result = generate_string_value(model, ids_list, id_to_token)
print("Valeur générée:", repr(result))
