import json
import src.models

try:
    with open("data/input/functions_definition.json") as f:
        content = json.load(f)
    for element in content:
        src.models.FunctionDefinition.model_validate(element)
        print(element)
except FileNotFoundError as e:
    print("ERROR", e)
except json.JSONDecodeError:
    print("error file JSON")