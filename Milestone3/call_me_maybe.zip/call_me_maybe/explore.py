"""Script d'exploration du llm_sdk - à lancer avec: uv run python explore.py"""
import json

from llm_sdk import Small_LLM_Model

print("Chargement du modèle...")
model = Small_LLM_Model()
print("Modèle chargé.\n")

vocab_path = model.get_path_to_vocab_file()
print("vocab_file:", vocab_path)
with open(vocab_path, encoding="utf-8") as f:
    vocab = json.load(f)
print("Type vocab:", type(vocab))
print("Taille vocab:", len(vocab))
print("Exemples (token -> id):", list(vocab.items())[:10])
print()

prompt = "What is the sum of 2 and 3?"
ids_tensor = model.encode(prompt)
print("input_ids (tensor):", ids_tensor)
ids_list = ids_tensor[0].tolist()
print("input_ids (list):", ids_list)
print()

print("decode(ids_list):", repr(model.decode(ids_list)))
print()

logits = model.get_logits_from_input_ids(ids_list)
print("nb logits (= taille vocab modèle):", len(logits))

max_idx = max(range(len(logits)), key=lambda i: logits[i])
print("token_id le plus probable:", max_idx, "logit:", logits[max_idx])
print("texte correspondant:", repr(model.decode([max_idx])))

# Vérifie les tokens spéciaux via tokenizer.json
tok_path = model.get_path_to_tokenizer_file()
with open(tok_path, encoding="utf-8") as f:
    tok_data = json.load(f)

added = tok_data.get("added_tokens", [])
print("Nombre de tokens ajoutés (spéciaux):", len(added))
print("Exemples:", added[:5])