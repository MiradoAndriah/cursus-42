"""Test: appliquer is_token_valid sur les VRAIS tokens du modèle."""
import json

from llm_sdk import Small_LLM_Model
from src.constrainer_func import is_token_valid

print("Chargement du modèle...")
model = Small_LLM_Model()
print("Modèle chargé.\n")

# Construit le mapping complet id -> texte (comme avant)
vocab_path = model.get_path_to_vocab_file()
with open(vocab_path, encoding="utf-8") as f:
    vocab = json.load(f)
id_to_token = {v: k for k, v in vocab.items()}

tok_path = model.get_path_to_tokenizer_file()
with open(tok_path, encoding="utf-8") as f:
    tok_data = json.load(f)
for tok in tok_data.get("added_tokens", []):
    id_to_token[tok["id"]] = tok["content"]

# Nos 5 noms de fonctions
all_names = [
    "fn_add_numbers",
    "fn_greet",
    "fn_reverse_string",
    "fn_get_square_root",
    "fn_substitute_string_with_regex",
]

# On simule qu'on a déjà écrit "fn_g"
already_written = "fn_g"

print(f"Recherche des tokens valides après already_written='{already_written}'...")
print("(ça va tester les 151936 tokens un par un, patience...)\n")

valid_token_ids = []
for token_id in range(len(id_to_token)):
    token_text = id_to_token.get(token_id)
    if token_text is None:
        continue
    if is_token_valid(already_written, token_text, all_names):
        valid_token_ids.append((token_id, token_text))

print(f"Nombre de tokens valides trouvés: {len(valid_token_ids)}")
print("Exemples:", valid_token_ids[:20])
