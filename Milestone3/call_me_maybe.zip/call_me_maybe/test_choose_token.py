"""Test: choose_next_token sur les vrais logits du modèle."""
import json

from llm_sdk import Small_LLM_Model
from src.constrainer_func import choose_next_token

print("Chargement du modèle...")
model = Small_LLM_Model()
print("Modèle chargé.\n")

# Mapping complet id -> texte
vocab_path = model.get_path_to_vocab_file()
with open(vocab_path, encoding="utf-8") as f:
    vocab = json.load(f)
id_to_token = {v: k for k, v in vocab.items()}

tok_path = model.get_path_to_tokenizer_file()
with open(tok_path, encoding="utf-8") as f:
    tok_data = json.load(f)
for tok in tok_data.get("added_tokens", []):
    id_to_token[tok["id"]] = tok["content"]

all_names = [
    "fn_add_numbers",
    "fn_greet",
    "fn_reverse_string",
    "fn_get_square_root",
    "fn_substitute_string_with_regex",
]

# On simule un prompt qui a déjà "fn_g" comme nom en cours
prompt = "Question: Greet shrek. Answer with a JSON: {\"name\": \"fn_g"
ids_tensor = model.encode(prompt)
ids_list = ids_tensor[0].tolist()

logits = model.get_logits_from_input_ids(ids_list)
print("Nombre de logits:", len(logits))

already_written = "fn_g"
best_id = choose_next_token(logits, already_written, all_names, id_to_token)

print("Token choisi (id):", best_id)
print("Texte du token choisi:", repr(id_to_token.get(best_id)))
