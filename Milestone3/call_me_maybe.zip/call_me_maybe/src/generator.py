from src import FunctionDefinition
from llm_sdk import Small_LLM_Model
from src import get_fullname_func, generate_string_value, generate_number_value, generate_bool_value, add_fixed_text

def find_function_definition(
        chosen_name: str,
        functions: list[FunctionDefinition]
    ) -> FunctionDefinition:
    for func in functions:
        if func.name == chosen_name:
            return func
    raise ValueError(f"ERROR: Function {chosen_name} is not found")


def generate_function_call(
        model: Small_LLM_Model,
        ids_list: list[int],
        all_functions: list[FunctionDefinition],
        id_to_token: dict[int, str],
    ) -> str:
    all_name = [func.name for func in all_functions]

    chosen_name = get_fullname_func(model, ids_list, all_name, id_to_token)
    func_def = find_function_definition(chosen_name, all_functions)

    result = '{"name": "' + chosen_name + '"' + add_fixed_text(model, ids_list, ', "parameters": {')
    name_params = list(func_def.parameters.keys())
    for i, name in enumerate(name_params):
        add_fixed_text(model, ids_list, f'"{name}": ')

        param_type = func_def.parameters[name].type
        if param_type == "number":
            value = generate_number_value(model, ids_list,id_to_token)
        elif param_type == "string":
            value = generate_string_value(model, ids_list, id_to_token)
        elif param_type == "boolean":
            value = generate_bool_value(model, ids_list, id_to_token)

        result += f'"{name}": ' + value
    
        if i < len(name_params) - 1:
            add_fixed_text(model, ids_list, ", ")
            result += ", "
    result += add_fixed_text(model, ids_list, '}}')
    return result