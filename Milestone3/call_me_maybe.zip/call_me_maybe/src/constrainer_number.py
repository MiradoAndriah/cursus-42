from llm_sdk import Small_LLM_Model
from src.constrainer_func import get_valid_function_names

def is_plausible_number_start(text: str) -> bool:
    if text == "":
        return True

    try:
        float(text)
        return True
    except ValueError:
        pass

    try:
        float(text + "0")
        return True
    except ValueError:
        return False


def is_plausible_string_start(text: str) -> bool:
    if text == "":
        return True
    return text.startswith('"')

    
def is_number_token_valid(already_written: str, token_text: str) -> bool:
    concate = already_written + token_text
    number = is_plausible_number_start(concate)
    if not number:
        return False
    return True

def is_value_token_valid(already_written: str, token_text: str, param_type: str) -> bool:
    if param_type == "number":
        return is_number_token_valid(already_written, token_text)
       
    elif param_type == "string":
        concate = already_written + token_text
        return is_plausible_string_start(concate)

    elif param_type == "boolean":
        concate = already_written + token_text
        possibilites = get_valid_function_names(concate, ["true", "false"])
        if len(possibilites) > 0:
            return True
        return False


def choose_next_number_token(
        logits: list[float],
        already_written: str,
        id_to_token: dict[int, str],
    ) -> int:
    filtered_logits = list(logits)          
    for token_id in range(len(logits)):
        token_text = id_to_token.get(token_id)
        if token_text is None:
            filtered_logits[token_id] = float('-inf')
            continue
        if not is_number_token_valid(already_written, token_text):
            filtered_logits[token_id] = float('-inf')

    best_id = max(range(len(filtered_logits)), key=lambda i: filtered_logits[i])
    return best_id

    
def generate_number_value(
        model: Small_LLM_Model,
        ids_list: list[int],
        id_to_token: dict[int, str]
    ) -> str:
    already_written = ""
    limite = 10
    while len(already_written) < limite:
        logits = model.get_logits_from_input_ids(ids_list)

        raw_best_id = max(range(len(logits)), key=lambda i: logits[i])
        raw_best_text = id_to_token.get(raw_best_id, "")
        if already_written and (raw_best_text.startswith(",") or raw_best_text.startswith("}")):
            break

        best_id = choose_next_number_token(logits, already_written, id_to_token)
        token_text = id_to_token[best_id]
        valid = is_number_token_valid(already_written, token_text)
        if valid:
            already_written += token_text
            ids_list.append(best_id)
        else:
            break
    return already_written
