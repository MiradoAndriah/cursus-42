from src.models import FunctionDefinition, Prompt
from pydantic import ValidationError
import json

def opening_file(file: str):
    try:
        with open(file) as f:
            data = json.load(f)
        return data
    except FileNotFoundError:
        raise ValueError(f"File not found: {file}")
    except json.JSONDecodeError:
        raise ValueError(f"Invalid JSON in file: {file}")


def parser_json(file: str) -> list[FunctionDefinition]:
    
    data = opening_file(file)
    result = []
    for element in data:
        try:
            func_def = FunctionDefinition(**element)
            result.append(func_def)
        except ValidationError as e:
            print(e)
    return result


def parser_prompts(file: str) -> list[Prompt]:

    data = opening_file(file)
    result = []
    for element in data:
        try:
            prompt = Prompt(**element)
            result.append(prompt)
        except ValidationError as e:
            print(e)
    return result

