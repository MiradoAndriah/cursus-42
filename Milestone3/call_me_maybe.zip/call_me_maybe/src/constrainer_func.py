from llm_sdk import Small_LLM_Model
"""Constrained decoding helpers for building valid JSON function calls."""

def add_fixed_text(model: Small_LLM_Model, ids_list: list[int], text: str) -> str:
    """Encode fixed text, append its tokens to ids_list, and return the text."""
    new_ids = model.encode(text)[0].tolist()
    ids_list.extend(new_ids)
    return text


def get_valid_function_names(already_written: str, all_names: list[str]) -> list[str]:
    return [name for name in all_names if name.startswith(already_written)]


def get_valid_next_chars(already_written: str, all_names: list[str]) -> tuple[set[str], set[str]]:
    value = get_valid_function_names(already_written, all_names)
    valid_char = set()
    fullname = set()

    for name in value:
        position = len(already_written)
        if position < len(name):
            next_char = name[position]
            valid_char.add(next_char)
        else:
            fullname.add(name)
    return valid_char, fullname


def is_token_valid(already_written: str, token_text: str, all_names: list[str]) -> bool:
    concate = already_written + token_text
    remaining_name = get_valid_function_names(concate, all_names)
    if len(remaining_name) > 0:
        return True
    return False


def choose_next_token(
    logits: list[float],
    already_written: str,
    all_names: list[str],
    id_to_token: dict[int, str],
) -> int:
    filtered_logits = list(logits)          

    for token_id in range(len(logits)):
        token_text = id_to_token.get(token_id)
        if token_text is None:
            filtered_logits[token_id] = float('-inf')
            continue
        if not is_token_valid(already_written, token_text, all_names):
            filtered_logits[token_id] = float('-inf')

    best_id = max(range(len(filtered_logits)), key=lambda i: filtered_logits[i])
    return best_id


def get_fullname_func(
        model: Small_LLM_Model,
        ids_list: list[int],
        all_names: list[str],
        id_to_token: dict[int, str]
    ) -> str:
    already_written = ""
    while True:
        logits = model.get_logits_from_input_ids(ids_list)
        best_id = choose_next_token(logits, already_written, all_names, id_to_token)
        token_text = id_to_token[best_id]
        already_written = already_written + token_text
        ids_list.append(best_id)
        _, full_names = get_valid_next_chars(already_written, all_names)
        if full_names:
            break
    return already_written

#------------------------------************--------------------------

#------------------------------***********---------------------------
# already_written = "fn_g"
# all_names = ["fn_add_numbers", "fn_greet", "fn_reverse_string", "fn_get_square_root", "fn_substitute_string_with_regex"]
# print("valid func name",get_valid_function_names(already_written, all_names))

# next = get_valid_next_chars("fn_ge", all_names)
# print(next)
# print(is_token_valid("fn_g", "reet", all_names))   # attendu: True
# print(is_token_valid("fn_g", "ff", all_names))    # attendu: False
# print(is_token_valid("", "fn_greet", all_names))
