from llm_sdk import Small_LLM_Model
from src.constrainer_func import add_fixed_text

def is_plausible_string_start(text: str) -> bool:
    if text == "":
        return True
    return text.startswith('"')


def choose_next_string_token(
        logits: list[float],
        already_written: str,
        id_to_token: dict[int, str],
    ) -> int:
    filtered_logits = list(logits)          
    for token_id in range(len(logits)):
        token_text = id_to_token.get(token_id)
        if token_text is None:
            filtered_logits[token_id] = float('-inf')
            continue
        if not is_plausible_string_start(already_written + token_text):
            filtered_logits[token_id] = float('-inf')

    best_id = max(range(len(filtered_logits)), key=lambda i: filtered_logits[i])
    return best_id


def generate_string_value(
        model: Small_LLM_Model,
        ids_list: list[int],
        id_to_token: dict[int, str]
    ) -> str:
    already_written = add_fixed_text(model, ids_list, '"')
    while True:
        logits = model.get_logits_from_input_ids(ids_list)
        best_id = choose_next_string_token(logits, already_written, id_to_token)
        token_text = id_to_token[best_id]
        already_written += token_text
        ids_list.append(best_id)
        if already_written.count('"') >= 2:
            index_fermeture = already_written.index('"', 1)
            already_written = already_written[:index_fermeture + 1]
            break
    return already_written