from src.constrainer_func import get_fullname_func
from llm_sdk import Small_LLM_Model


def generate_bool_value( model: Small_LLM_Model,
        ids_list: list[int],
        id_to_token: dict[int, str]
    ) -> str:
    result = get_fullname_func(
        model,
        ids_list,
        ["true", "false"],
        id_to_token)
    return result